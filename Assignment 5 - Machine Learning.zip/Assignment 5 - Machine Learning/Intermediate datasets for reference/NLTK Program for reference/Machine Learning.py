import nltk
import csv
import pandas as pd
pos_tags = []
with open('test.csv', encoding="utf8", errors = 'ignore') as file:
    reader = csv.reader(file)
    for row in reader:
        #row.encode('utf-8').strip()
        sentence = (row[0].split())
        pos_tag = nltk.pos_tag(sentence)
        pos_tags.append(pos_tag)

gold_class = {}
for i in range(0, len(pos_tags)):
    sentence = pos_tags[i]
    for j in range(0, len(sentence)):
        pos_tag = sentence[j]
        word = pos_tag[0]
        tag = pos_tag[1]
        if(tag in ('NN','NNS','NNP','NNPS', 'VB','VBD','VBG','VBN','VBP','VBZ','JJ','JJR','JJS')):
            if word in gold_class:
                gold_class[word] += 1
            else:
                gold_class[word] = 1


label = []
count = 0
with open('test.csv', encoding="utf8", errors = 'ignore') as file:
    reader = csv.reader(file)
    for row in reader:
        sentence = (row[0].split())
        print(sentence)
        flag = 0
        count += 1
        #print(flag)
        for i in range(len(sentence)):
            word = sentence[i]
            if word not in gold_class.keys():
                flag = 1
                break
        label.append(flag)

    file.close()

count = 0
for i in label:
    if(i == 0):
        count += 1

print(count)

with open('returns1.csv', 'w') as f:
    writer = csv.writer(f)
    writer.writerows(zip(label));


